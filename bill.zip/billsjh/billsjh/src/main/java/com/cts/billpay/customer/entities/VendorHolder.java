package com.cts.billpay.customer.entities;

public class VendorHolder {

	public VendorHolder() {
		// TODO Auto-generated constructor stub
	}

	private String type;
	private String amount;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}
}
